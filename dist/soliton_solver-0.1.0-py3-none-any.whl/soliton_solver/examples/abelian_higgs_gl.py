# =====================================================================================
# abelian_higgs_gl.py
# =====================================================================================
"""
To run: python -m soliton_solver.examples.abelian_higgs_gl
"""
from soliton_solver.theories import load_theory
from soliton_solver.core.simulation import Simulation

theory = load_theory("Ginzburg-Landau superconductor")

def run_gl_simulation():
    params = theory.params.default_params(
        xlen=320, ylen=320, xsize=50.0, ysize=50.0,     # Grid params 
        q=1.0, Lambda=0.5, u1=1.0,                      # Abelian Higgs parameters
        newtonflow=False,                               # Start simulation with flow on/off (True/False)
        unit_magnetization=False                        # Required flag for magnetization (False if no magnetization)
        )
    sim = Simulation(params, theory)
    sim.initialize({"mode": "ground"})
    theory.render_gl.run_viewer(sim, sim.rp, steps_per_frame=5)

if __name__ == "__main__":
    run_gl_simulation()